﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class HoaDon
    {
        //private int HD_ID,
        //private int OrderID,
        //private bool Delivered,
        //private int KH_ID,
        //private int OrderID,
        //private int OrderID,
        //private int OrderID,
        //private int OrderID,
        //private int OrderID,
        //private int OrderID,
        //private int OrderID,



    }
}
